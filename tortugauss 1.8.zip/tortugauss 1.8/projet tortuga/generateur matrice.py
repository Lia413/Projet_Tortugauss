import numpy as np
import random as rd


def Bbon(b):
    for i in b:
        if abs(i) < 2 or abs(i) > 9:
            return False
    return True


taille = 3
listeA = ""
listeB = ""
for k in range(10):
    B = [11 for i in range(taille)]
    while not Bbon(B):
        A = []
        StrA = "np.array(["
        for i in range(taille):
            StrA += "["
            for j in range(taille):
                A.append(rd.randrange(-6, 7))
                StrA += str(A[-1]) + ","
            StrA = StrA[:-1]
            StrA += "],"
        StrA = StrA[:-1]
        StrA += "], dtype=np.float64)," + "#" + str(k + 33) + "\n"
        X = []
        for i in range(taille):
            X.append(rd.randrange(-25, 25) / 10)
        StrB = "np.array(["
        for i in range(taille):
            B[i] = 0
            for j in range(taille):
                B[i] += A[i * taille + j] * X[j]

            B[i] = round(B[i], 1)
            StrB += str(B[i]) + ","
        StrB = StrB[:-1]
        StrB += "], dtype=np.float64)," + "#" + str(k + 33) + "\n"
    listeA += StrA
    listeB += StrB


print(listeA, "\n\n", listeB)

"""
    np.array([[2, 1], [1, 4]], dtype=np.float64),
    np.array([[1.0, 0], [0, 1.5]], dtype=np.float64),
    np.array([[1, 0, 0], [0, 2, 0], [0, 0, 4]], dtype=np.float64),
    np.array([[3.3, 0.9], [0.2, 4.0]], dtype=np.float64),
    np.array([[2.2, 3.2], [3.9, 3.4]], dtype=np.float64),
    np.array([[2.9, 0.7], [3.2, 3.6]], dtype=np.float64),
    np.array([[1.9, 2.6], [0.1, 3.9]], dtype=np.float64),
    np.array([[2.6, 3.4], [2.4, 1.9]], dtype=np.float64),
    np.array([[1.7, 1.2], [0.3, 0.2]], dtype=np.float64),
    np.array([[3.2, 3.9], [0.6, 0.3]], dtype=np.float64),
    np.array([[2.5, 2.7], [3.4, 0.8]], dtype=np.float64),
    np.array([[3.2, 0.9], [3.0, 0.5]], dtype=np.float64),
    np.array([[1.1, 1.8], [0.5, 2.2]], dtype=np.float64),
    np.array([[0.9, 0.2, 0.7], [0.8, 2.2, 3.5], [3.6, 2.2, 3.2]], dtype=np.float64),
    np.array([[0.2, 0.9, 2.7], [2.5, 2.5, 0.1], [1.3, 3.8, 3.6]], dtype=np.float64),
    np.array([[3.6, 2.7, 2.9], [2.9, 2.5, 2.1], [2.9, 1.3, 1.2]], dtype=np.float64),
    np.array([[3.1, 3.0, 0.6], [0.0, 2.3, 2.2], [1.4, 1.7, 2.0]], dtype=np.float64),
    np.array([[0.8, 1.0, 3.0], [1.8, 1.8, 0.7], [3.1, 0.1, 1.0]], dtype=np.float64),
    np.array([[1.7, 0.7, 0.8], [0.0, 1.8, 2.7], [3.8, 0.8, 2.0]], dtype=np.float64),
    np.array([[0.1, 3.0, 4.0], [0.1, 2.1, 3.6], [0.2, 1.4, 1.0]], dtype=np.float64),
    np.array([[2.4, 3.4, 1.6], [1.4, 4.0, 0.1], [2.1, 2.3, 0.9]], dtype=np.float64),
    np.array([[1.4, 1.9, 1.1], [1.8, 2.7, 0.2], [1.5, 2.1, 0.9]], dtype=np.float64),
    np.array([[1.1, 0.3, 3.9], [0.9, 0.7, 1.7], [3.4, 2.3, 2.9]], dtype=np.float64),
    np.array([[2.1, 3.2, 2.2], [3.0, 1.3, 0.8], [3.6, 1.5, 3.1]], dtype=np.float64),
    np.array([5, 6], dtype=np.float64), 
    np.array([2.5, 2.5], dtype=np.float64),
    np.array([2.5, 2.5, 2.5], dtype=np.float64),
    np.array([-0.63, 1.54], dtype=np.float64),
    np.array([1.78, 1.11], dtype=np.float64),
    np.array([1.02, 0.56], dtype=np.float64),
    np.array([-2.75, -1.65], dtype=np.float64),
    np.array([-1.46, -1.1], dtype=np.float64),
    np.array([2.49, 0.43], dtype=np.float64),
    np.array([-0.95, 0.21], dtype=np.float64),
    np.array([-1.02, -1.1], dtype=np.float64),
    np.array([2.7, 2.6], dtype=np.float64),
    np.array([0.81, 1.75], dtype=np.float64),
    np.array([0.55, 1.64, 2.36], dtype=np.float64),
    np.array([1.26, -3.43, -0.55], dtype=np.float64),
    np.array([3.11, 2.47, 1.36], dtype=np.float64),
    np.array([1.07, 3.18, 1.52], dtype=np.float64),
    np.array([1.48, 1.94, 2.1], dtype=np.float64),
    np.array([-0.99, -1.44, -2.96], dtype=np.float64),
    np.array([0.7, 0.09, 0.76], dtype=np.float64),
    np.array([1.08, 1.2, 0.91], dtype=np.float64),
    np.array([-1.95, -3.71, -2.37], dtype=np.float64),
    np.array([-0.18, -0.16, -1.06], dtype=np.float64),
    np.array([-3.25, -3.29, -3.05], dtype=np.float64),"""
